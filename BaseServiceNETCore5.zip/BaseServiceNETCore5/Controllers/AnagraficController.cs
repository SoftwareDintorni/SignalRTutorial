﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class AnagraficController : ControllerBase
    {

        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "Get Anagrafic: " + id.ToString();
        }

    }
}
