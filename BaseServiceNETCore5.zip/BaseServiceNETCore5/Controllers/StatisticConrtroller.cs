﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class StatisticController : ControllerBase
    {
        [HttpGet]
        public string Get()
        {
            return "questa è una get generica";
        }

        [HttpGet("{id}")]
        public string Get(string id)
        {
            return "questa è una get per l`` id " + id;
        }

    }
}
