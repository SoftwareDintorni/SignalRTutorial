﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonCore.Poco
{
    public class Enumerators
    {
        public enum httpVerb
        {
            GET,
            POST,
            PUT,
            DELETE
        }
    }
}
