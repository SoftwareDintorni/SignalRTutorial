﻿using Common.Core;
using Microsoft.AspNetCore.SignalR.Client;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using WpfTimeClient.Common.Base;

namespace WpfTimeClient.ViewModel
{
   public class MainWindowViewModel: NotifyPropertyChanged
    {
        #region Ctor
        public MainWindowViewModel()
        {
            Task.Run(async () => {
                try
                {
                  
                    connection = new HubConnectionBuilder()
                    .WithUrl("https://localhost:44345/SignalRHub")
                    .Build();

                    try
                    {
                        await connection.StartAsync();
                        await Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => MessagesList.Add("Connection started")));
                    }
                    catch (Exception ex)
                    {
                        Label = ex.Message;
                        await Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => MessagesList.Add(ex.Message)));
                    }
                    // Gestione del Messaging legato a SignalR
                    connection.On<string>("Send", (message) =>
                    {
                         Label = message;
                         Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => MessagesList.Add(message)));
                        
                     

                    });


                }
                catch (Exception ex)
                {
                    Label = ex.Message;
                     await Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => MessagesList.Append(ex.Message)));
                }
            });
        }

        #endregion
        #region ReayCommand
        /// <summary>
        /// relay command for close dialog command
        /// </summary>
        private RelayCommand relayCloseDialog;

        //private RelayCommand relayGetString;
        private RelayCommand relayGetCountinuousString;
        private RelayCommand relayStopContinuousRead;

        #endregion
        #region Attribute
        private RestClient rClient = new RestClient();
        private string _label = string.Empty;
        private ObservableCollection<string> _messagesList = new ObservableCollection<string>() ;
        private string _timeStartedStatus = string.Empty;
        private Microsoft.AspNetCore.SignalR.Client.HubConnection connection;
        #endregion
        #region Propertites

        public string Label
        {
            get => this._label;
            set
            {
                this._label = value;
                this.OnPropertyChanged("Label");
            }
        }

        public ObservableCollection<string> MessagesList 
        {
            get => this._messagesList;
            set
            {
                this._messagesList = value;
                this.OnPropertyChanged("MessagesList");
            }
        }

        public string TimeStartedStatus
        {
            get => this._timeStartedStatus;
            set
            {
                this._timeStartedStatus = value;
                this.OnPropertyChanged("TimeStartedStatus");
            }
        }

        #endregion
        #region Functions

        private void Close(object sender)
        {
            App.Current.Shutdown();
        }

        private void UpdateTimeStop(object sender)
        {
            rClient.endPoint = "https://localhost:44345/api/v1/Timer/StopContinuousRead";
            string retval = rClient.makeRequest();
            Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => MessagesList.Add("Thread "+retval)));
            TimeStartedStatus = retval;
            
        }
        private void UpdateTimeStart(object sender)
        {
            rClient.endPoint = "https://localhost:44345/api/v1/Timer/StartContinuousRead";
            string retval = rClient.makeRequest();
            Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() => MessagesList.Add("Thread " + retval)));
            TimeStartedStatus = retval;

        }

        public ICommand CloseApp
        {
            get
            {
                if (this.relayCloseDialog == null)
                {
                    this.relayCloseDialog = new RelayCommand(param => this.Close(param));
                }

                return this.relayCloseDialog;
            }
        }
        public ICommand StartTimeMonitor
        {
            get
            {
                if (this.relayGetCountinuousString == null)
                {
                    this.relayGetCountinuousString = new RelayCommand(param => this.UpdateTimeStart(param));
                }

                return this.relayGetCountinuousString;
            }
        }
        public ICommand StopTimeMonitor
        {
            get
            {
                if (this.relayStopContinuousRead == null)
                {
                    this.relayStopContinuousRead = new RelayCommand(param => this.UpdateTimeStop(param));
                }

                return this.relayStopContinuousRead;
            }
        }

        #endregion








    }
}
