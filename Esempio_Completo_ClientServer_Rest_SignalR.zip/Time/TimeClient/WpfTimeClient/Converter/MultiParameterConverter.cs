﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;

namespace WpfTimeClient.Converter
{
    /// <summary>
    /// Used to support multi parameter Converter
    /// </summary>
    public class MultiParameterConverter : MarkupExtension, IMultiValueConverter
    {
        /// <summary>
        ///  convert Object array to Object
        /// </summary>
        /// <param name="values">values array</param>
        /// <param name="targetType">target type</param>
        /// <param name="parameter">Parameter Object </param>
        /// <param name="culture">Culture info </param>
        /// <returns>an object tat sum the values</returns>
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return values.Clone();
        }

        /// <summary>
        ///  convert back the parameter <c>Not implemented because not used</c>
        /// </summary>
        /// <param name="value">Object value </param>
        /// <param name="targetTypes"> array of type</param>
        /// <param name="parameter">Parameter Object</param>
        /// <param name="culture">Reference to culture</param>
        /// <returns> return an object array</returns>
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return this;
        }
    }
}
