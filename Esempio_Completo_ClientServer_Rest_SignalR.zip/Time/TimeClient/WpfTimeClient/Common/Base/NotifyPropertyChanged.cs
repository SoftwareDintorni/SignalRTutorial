﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace WpfTimeClient.Common.Base
{
    /// <summary>
    /// public abstract class to help the developer to bind data
    /// </summary>
    public class NotifyPropertyChanged : INotifyPropertyChanged
    {
        #region INotifyPropertyChanged implementation

        /// <summary>
        /// property changed event
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion       

        /// <summary>
        /// manage the property changed method
        /// </summary>
        /// <param name="propertyName"> property name </param>
        public virtual void OnPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged == null)
            {
                return;
            }

            this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// method to execute the property change and update of local variable
        /// </summary>
        /// <typeparam name="T">type undefined</typeparam>
        /// <param name="backingStore">backing Store that contain old value </param>
        /// <param name="value"> new value</param>
        /// <param name="propertyName">property Name</param>
        /// <param name="onChanged">on changed </param>
        protected void SetProperty<T>(ref T backingStore, T value, [CallerMemberName] string propertyName = "", Action onChanged = null)
        {
            if (EqualityComparer<T>.Default.Equals(backingStore, value))
            {
                return;
            }
            backingStore = value;
            onChanged?.Invoke();

            this.OnPropertyChanged(propertyName);
        }
    }
}
