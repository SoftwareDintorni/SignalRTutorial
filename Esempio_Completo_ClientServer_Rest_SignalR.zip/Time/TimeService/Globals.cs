﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TimeService
{
    public static class Globals
    {
        public static bool continuousTimeRead = false;
    }
}
