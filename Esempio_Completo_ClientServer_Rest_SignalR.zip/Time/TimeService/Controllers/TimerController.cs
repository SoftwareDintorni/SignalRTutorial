﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimeService.Hubs;
using TimeService.Services;

namespace TimeService.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class TimerController : ControllerBase
    {
        private readonly LocalDataService _service;
        private readonly IHubContext<SignalRHub> _hubContext;



        public TimerController(LocalDataService localDataSvc, IHubContext<SignalRHub> hubContext)
        {
            _hubContext = hubContext;
            _service = localDataSvc;
        }

        /// <summary>
        /// Avvia la lettura continua del timer
        /// </summary>
        /// <returns> Continuous read</returns>
        [HttpGet("StartContinuousRead")]
        public async Task<IActionResult> GetContinuousRead()
        {
            if (!ModelState.IsValid)
                return BadRequest("GetContinuousRead - Decoding Table Generic Error");

            try
            {
                return Ok(_service.StartReadContinuousTimer(_hubContext).Result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        /// <summary>
        /// Ferma la lettura continua del timer
        /// </summary>
        /// <returns></returns>
        [HttpGet("StopContinuousRead")]
        public async Task<IActionResult> StopContinuousRead()
        {
            if (!ModelState.IsValid)
                return BadRequest("StopContinuousRead - data Error");

            try
            {
                return Ok(await _service.StopReadContinuousTimer());

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }


        }

    }
}
