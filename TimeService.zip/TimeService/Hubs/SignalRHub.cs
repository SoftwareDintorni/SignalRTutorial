﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

namespace TimeService.Hubs
{
    public class SignalRHub : Hub
    {
        #region HubMethods

        public Task SendMessage(string user, string message)
        {
            return Clients.All.SendAsync("ReceiveMessage", user, message);
        }

        public Task SendToCaller(string message)
        {
            return Clients.Caller.SendAsync("ReceiveMessage", message);
        }

        public Task SendToGroup(string userGroup, string message)
        {
            return Clients.Group(userGroup).SendAsync("ReceiveMessage", message);
        }

        #endregion

        #region HubMethodName
        [HubMethodName("SendMessageToUse")]
        public Task DirectMessage(string user, string message)
        {
            return Clients.User(user).SendAsync("ReceiveMessage", message);
        }
        #endregion

        #region ThrowHubException
        public Task throwException()
        {
            throw new HubException("Questo errore verrà spedito al client!!");
        }

        #endregion

        #region OnConnectedAsync
        public override async Task OnConnectedAsync()
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, "SignalRUser");
            await base.OnConnectedAsync();

        }
        #endregion

        #region OnDisconnectedAsync
        public override async Task OnDisconnectedAsync(Exception exception)
        {
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, "SignalRUser");
            await base.OnDisconnectedAsync(exception);
        }
        #endregion
    }
}
