﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using TimeService.Hubs;

namespace TimeService.Services
{
    public partial class LocalDataService
    {
        public async Task<string>StopReadContinuousTimer()
        {
            Globals.continuousTimeRead = false;
            return "Stop Ciclo";
        }

        private async static void ThreadProc(IHubContext<SignalRHub> hubContext)
        {
            while (Globals.continuousTimeRead)
            {
                //WCF?
                await hubContext.Clients.All.SendAsync("Send", "messaggio:" + DateTime.Now.ToLongTimeString());
                await Task.Delay(1000);
            }
        }

        public async Task<string> StartReadContinuousTimer(IHubContext<SignalRHub> hubContext)
        {
            try
            {
                Globals.continuousTimeRead = true;

                new Thread(delegate () {
                    ThreadProc(hubContext);
                }).Start();

                return "Messaggio avviato";
            }
            catch (Exception ex)
            {
                return "Messaggio nok";
            }
        }
    }
}
